<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 <!-- CSRF Token -->
 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>E-Ticketing</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet">

    <!-- Styles -->
    <style>
        body {
            font-family: 'Figtree', sans-serif;
        }
    </style>
</head>
<body class="">


    
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
            <!-- Navbar Brand and Toggle Button -->
            <a class="navbar-brand" href="#">SMART Poribahan</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
    </div>
    <div class="container">
            <!-- Navbar Links -->
            <div class="collapse navbar-collapse mx-auto justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                    <li class="nav-item">
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-primary">Dashboard</a>
                        <?php else: ?>
                                <a class="btn btn-outline-primary me-2" href="<?php echo e(route('login')); ?>">Log in</a>

                            <?php if(Route::has('register')): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Register</a>
                            <?php endif; ?>
                        <?php endif; ?>
                      <?php endif; ?>
                    </li>
                </ul>
            </div>

            <!-- Login and Register Buttons on the Right -->
            <!-- <div class="d-flex">
                <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-primary">Dashboard</a>
                        <?php else: ?>
                                <a class="btn btn-outline-primary me-2" href="<?php echo e(route('login')); ?>">Log in</a>

                            <?php if(Route::has('register')): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Register</a>
                            <?php endif; ?>
                        <?php endif; ?>
                <?php endif; ?>
            </div> -->
        </div>
    </nav>
    <!-- End of Topbar -->
    <main id="main_content" class="py-2">
                    <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- End of Main Content -->

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/custom.js"></script>
</body>
</html>

<!-- ======================== Footer ===================== -->
<?php /**PATH D:\01. My Project\00. All Laravel Project\Ostad  Project\bus-ticketing-system\resources\views/layouts/home_app.blade.php ENDPATH**/ ?>