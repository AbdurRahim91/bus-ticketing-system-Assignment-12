 <!-- Adjust this based on your layout setup -->

<?php $__env->startSection('content'); ?>
   <div class="container min-vh-100">
       <div class="row">
          <div class="col-12 text-center">

                <div class="alert alert-danger">
                    <h3>Please log in to proceed with the purchase.</h3>
                </div>

			</div>
        </div>	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01. My Project\00. All Laravel Project\Ostad  Project\bus-ticketing-system\resources\views/notice.blade.php ENDPATH**/ ?>