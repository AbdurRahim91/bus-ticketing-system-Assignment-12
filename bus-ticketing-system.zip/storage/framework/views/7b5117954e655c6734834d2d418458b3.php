

    <?php $__env->startSection('content'); ?>
    <div class="container mt-5">
    <div class="row mt-5 mb-5">
			<div class="col-md-6 ">
				<div class="card mt-3 border border-primary ">
					<div class="card-body">
						<form action = "<?php echo e(route('bus_view')); ?>" method="POST">  
                        <?php echo csrf_field(); ?>
						  <div class="form-group my-2">
							<label for="from">Boarding Point:</label>
							<select class="form-control" name="from" id="from" required>
								<option value="">Select Boarding Point</option>
                                <?php $__currentLoopData = $busStops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stopName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($stopName); ?>"><?php echo e($stopName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						   </div>
														
						   <div class="form-group my-2">
							<label for="to">Dropping Point:</label>
							<select class="form-control" name="to" id="to" required>
								<option value="">Select Dropping Point</option>
                                <?php $__currentLoopData = $busStops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stopName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($stopName); ?>"><?php echo e($stopName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						   </div>
							
							<div class="my-2"> 
								<label for = "doj"> Date Of Journey: </label>  
								<input type = "date"  id="doj" class = "form-control" name = "doj" placeholder = "Select Date Of Journey" required>  
							</div>   
							<button type = "submit" name="submit" class = "btn btn-danger text-center"> Search Bus </button>  
							</form>   
					</div>
				  </div>
				
			</div>
			<div class="col-md-4 order-first order-md-last">
				<span><img src="<?php echo e(asset('assets/img/home_bus.jpg')); ?>" alt="Image Missing" style="width: 500px; height: 300px;" ></span>
			  </div>
		  </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01. My Project\00. All Laravel Project\Ostad  Project\bus-ticketing-system\resources\views/index.blade.php ENDPATH**/ ?>