<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('User Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="container mx-auto mt-8 p-4 bg-white rounded-lg shadow-md">
                        <h1 class="text-2xl text-slate-700 font-semibold mb-4">Bus Ticket Information</h1>
                    
                        <!-- Bus Ticket Table -->
                        <div class="overflow-x-auto">
                            <table class="min-w-full bg-white border border-gray-300">
                                <thead>
                                <tr class="bg-sky-600 text-white">
                                    <th class="py-2 px-4 border-b">Trip Name</th>
                                    <th class="py-2 px-4 border-b">Coach No</th>
                                    <th class="py-2 px-4 border-b">Starting Counter</th>
                                    <th class="py-2 px-4 border-b">End Counter</th>
                                    <th class="py-2 px-4 border-b">Date</th>
                                    <th class="py-2 px-4 border-b">Seat</th>
                                    <th class="py-2 px-4 border-b">Price</th>
                                    <th class="py-2 px-4 border-b">Download</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ticketSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticketSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="duration-300 text-center">
                                        <td class="py-2 px-4 border-b"><?php echo e($ticketSale->id); ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo e($ticketSale->bus_id); ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo e($ticketSale->from); ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo e($ticketSale->to); ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo e($ticketSale->doj); ?></td>
                                        <td class="py-2 px-4 border-b font-semibold"><?php echo e($ticketSale->seat); ?></td>
                                        <td class="py-2 px-4 border-b text-green-500 font-semibold"><?php echo e($ticketSale->fare); ?></td>
                                        <td class="py-2 px-4 border-b">
                                            <a href="<?php echo e(url('print_pdf',$ticketSale->id)); ?>" class="bg-rose-500 p-1.5 rounded-md border-2 text-white hover:border-sky-600 hover:border-2 hover:bg-white hover:text-rose-600 duration-500">Download</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH H:\xampp\htdocs\online_ticketing_system\resources\views/userDashboard/index.blade.php ENDPATH**/ ?>