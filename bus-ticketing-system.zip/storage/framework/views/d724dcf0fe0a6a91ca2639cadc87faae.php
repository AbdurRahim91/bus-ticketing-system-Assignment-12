<!-- bus_view.blade.php -->

 <!-- Adjust this based on your layout setup -->

<?php $__env->startSection('content'); ?>
   <div class="container min-vh-100">
       <div class="row">
          <div class="col-12">
            <div class="shadow p-3 mt-3 bg-body rounded alert-primary">
                <p>Total Number of Buses: <?php echo e($total_no); ?></p>
              <h4><b><span class="alert-danger">Search Result :</span>Leaving From:</b>&nbsp;<span><?php echo e($from); ?></span>&nbsp;&nbsp;<b>Going To:</b>&nbsp;<span><?php echo e($to); ?></span> &nbsp;&nbsp;<br><b>Journey Date:</b>&nbsp;<span><?php echo e($doj); ?></span></h4>
            </div>
          </div>
        </div>
        <div class="row mt-2 mb-5">
			<div class="col-12 ">
				<div class="card mt-3 border border-primary ">
					<div class="card-body table-responsive">
                        <table class="table table-striped table-hover responsive">
                        <thead class="bg-info">
                            <tr>    
                                <th>Coach No</th>
                                <th>Starting Counter</th>                   
                                <th>Departing Time </th>
                                <th>End Counter</th> 
                                <th>Arrival Time</th>  
                                <th>Coach Type</th>                     
                                <th>Fare</th> 
                                <th>Seats Available</th>                           
                                <th>View</th>  
                            </tr>
                        </thead>
                        <tbody>

                            <tr> 
                            <?php if($busInfoResults->isEmpty()): ?>
                                <td class='text-center' colspan='9'>No buses found for the selected criteria.</td>
                                <?php else: ?>
                                    <?php $__currentLoopData = $busInfoResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($bus->coach_name); ?></td>
                                    <td><?php echo e($bus->boarding_point); ?></td>
                                    <td><?php echo e($bus->boarding_time); ?></td>
                                    <td><?php echo e($bus->dropping_point); ?></td>
                                    <td><?php echo e($bus->dropping_time); ?></td>
                                    <td><?php echo e($bus->coach_type); ?></td>
                                    <td><?php echo e($bus->fare); ?></td>
                                    <td><?php echo e($bus->total_seats-$total_ticket_sold); ?> /<?php echo e($bus->total_seats); ?> </td>
                                    <td>
                                        <form action="<?php echo e(route('buy_now')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input name="bus_id" value="<?php echo e($bus->bus_id); ?>" hidden>
                                            <input name="coach_name" value="<?php echo e($bus->coach_name); ?>" hidden>
                                            <input name="coach_type" value="<?php echo e($bus->coach_type); ?>" hidden>
                                            <input name="boarding_point" value="<?php echo e($bus->boarding_point); ?>" hidden>
                                            <input name="dropping_point" value="<?php echo e($bus->dropping_point); ?>" hidden>
                                            <input name="doj" value="<?php echo e($doj); ?>" hidden>
                                            <input name="from" value="<?php echo e($from); ?>" hidden>
                                            <input name="to" value="<?php echo e($to); ?>" hidden>
                                            <input name="fare" value="<?php echo e($bus->fare); ?>" hidden>
                                            
                                           
                                                <?php
                                                    $difference = $total_ticket_sold - $bus->total_seats;
                                                ?>
                                                <input name="available_seat" value="<?php echo e($difference); ?>" hidden>
                                                <?php if($difference >= 0): ?>
                                                    <button type="submit" class="btn btn-danger btn-sm" disabled>Sold out</button>
                                                <?php else: ?>
                                                    <button type="submit" class="btn btn-success btn-sm">Buy Now</button>
                                                <?php endif; ?>
                                        </form>
                                     </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>    
                              </tr>
                        </tbody>
                        </table>
					</div>
				  </div>
			</div>
        </div>	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01. My Project\00. All Laravel Project\Ostad  Project\bus-ticketing-system\resources\views/bus_view.blade.php ENDPATH**/ ?>