 <!-- Adjust this based on your layout setup -->

<?php $__env->startSection('content'); ?>
   <div class="container min-vh-100">
       <div class="row justify-content-center">
          <div class="col-md-6">

                <div class="">
                    <h3 class="text-center">Checkout Page</h3>
                    <h3 class="text-center">Coach Name: <?php echo e($coach_name); ?>-[<?php echo e($coach_type); ?>]</h3>
                    <form action="<?php echo e(route('checkoutFinal')); ?>" method="post">
                       <?php echo csrf_field(); ?>
                       <input type="text" class="form-control" name="user_id" value="<?php echo e($user_id); ?>" hidden>
                       <input type="text" class="form-control" name="bus_id" value="<?php echo e($bus_id); ?>" hidden>
                        <div class="form-group">
                            <label for="from">From</label>
                            <input type="text" class="form-control" name="from" value="<?php echo e($from); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="to">To</label>
                            <input type="text" class="form-control" name="to" value="<?php echo e($to); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="doj">Jurny Date</label>
                            <input type="text" class="form-control" name="doj" value="<?php echo e($doj); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="seat">Seats [Available seat(s)-<?php echo e($available_seat); ?>]</label>
                            <input type="number" class="form-control" name="seat" id="seatInput" max="4" oninput="calculateAmount()">
                            <input type="text" class="form-control" name="fare" id="fareInput" value="<?php echo e($fare); ?>" hidden>
                        </div>
                        <div class="form-group">
                            <label for="amount">Total Amount</label>
                            <input type="text" class="form-control" name="amount" id="amount" readonly>
                        </div>


                    <button type="submit" class="btn btn-success">Submit</button>
                    </form>
                </div>

			</div>
        </div>	
</div>
<script>
    function calculateAmount() {
        // Get the value of the seat input
        var seatInput = document.getElementById('seatInput').value;
        var fareInput = document.getElementById('fareInput').value;

        // Calculate the total amount (assuming $1000 per seat)
        var amount = seatInput * fareInput;

        // Update the value of the "Total Amount" input field
        document.getElementById('amount').value = amount;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ostad_php_laravel_assignments\Bus\online_ticketing_system\resources\views/checkout.blade.php ENDPATH**/ ?>