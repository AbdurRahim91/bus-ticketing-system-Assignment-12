@extends('layouts.home_app') <!-- Adjust this based on your layout setup -->

@section('content')
   <div class="container min-vh-100">
       <div class="row">
          <div class="col-12 text-center">

                <div class="alert alert-danger">
                    <h3>Please log in to proceed with the purchase.</h3>
                </div>

			</div>
        </div>	
</div>
@endsection